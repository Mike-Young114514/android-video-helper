安卓浏览器插件 + 辅助应用（源码包）

内容：
- browser_extension/：Manifest V3 浏览器扩展，扫描网页直链视频并复制地址。
- android_helper/：Android Studio 项目，接收分享/粘贴的 URL，下载直链文件；尝试把简单的未加密 HLS VOD 分片顺序拼接为 .ts。

安装扩展：解压 ZIP，在支持 Chrome 扩展的安卓浏览器中尝试加载 browser_extension/。并非所有 Kiwi Browser 版本都支持本地加载；安卓官方 Chrome 通常不支持扩展。

构建安卓辅助应用：使用电脑安装 Android Studio，打开 android_helper 文件夹并等待 Gradle 同步，再构建 APK。此 ZIP 是源码项目，不是已编译 APK。

使用流程：浏览器插件扫描并复制 URL；打开安卓辅助程序粘贴 URL 并开始下载。普通直链交给系统下载管理器；未加密 HLS 尝试保存为 TS 文件。浏览器扩展与应用未建立自动原生消息桥接，因此通过复制/粘贴或分享菜单传递 URL。

限制：基础 HLS 处理不支持所有主播放列表、直播、DASH/MPD、字幕、加密密钥或复杂 Cookie/请求头。不会破解 DRM，也不会绕过登录、付费或访问控制。仅下载有权保存的内容。
