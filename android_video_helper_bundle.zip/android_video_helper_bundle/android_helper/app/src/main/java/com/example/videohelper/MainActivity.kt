package com.example.videohelper

import android.app.Activity
import android.app.DownloadManager
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.os.Environment
import android.view.Gravity
import android.view.ViewGroup
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import java.net.HttpURLConnection
import java.net.URL
import java.io.File
import java.io.FileOutputStream

class MainActivity : Activity() {
 private lateinit var input: EditText
 private lateinit var status: TextView
 override fun onCreate(savedInstanceState: Bundle?) { super.onCreate(savedInstanceState)
  val root=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(20,28,20,20)}
  root.addView(TextView(this).apply{text="安卓视频辅助程序";textSize=22f})
  root.addView(TextView(this).apply{text="粘贴浏览器插件复制的视频 URL。支持直接媒体文件和简单的未加密 HLS (.m3u8)；不支持 DRM 解密。";textSize=14f;setPadding(0,10,0,14)})
  input=EditText(this).apply{hint="粘贴 http(s) 视频地址";minLines=3;gravity=Gravity.TOP}
  root.addView(input,LinearLayout.LayoutParams(-1,ViewGroup.LayoutParams.WRAP_CONTENT))
  root.addView(Button(this).apply{text="开始下载";setOnClickListener{startDownload(input.text.toString().trim())}})
  status=TextView(this).apply{text="文件将保存到下载目录或应用下载目录。";setPadding(0,14,0,0)};root.addView(status)
  setContentView(ScrollView(this).apply{addView(root)})
  val shared=if(intent?.action==Intent.ACTION_SEND) intent.getStringExtra(Intent.EXTRA_TEXT).orEmpty() else ""
  if(shared.isNotBlank()) input.setText(shared)
 }
 private fun startDownload(raw:String){val uri=runCatching{Uri.parse(raw)}.getOrNull();if(uri==null||uri.scheme !in listOf("http","https")||uri.host.isNullOrBlank()){status.text="请粘贴有效的 http/https 地址。";return}
  if(uri.path.orEmpty().lowercase().endsWith(".m3u8")){status.text="开始处理未加密 HLS……";Thread{downloadHls(raw)}.start()}else try{val req=DownloadManager.Request(uri).setTitle(uri.lastPathSegment?:"video").setDescription("网页视频下载").setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED).setAllowedOverMetered(true).setAllowedOverRoaming(false).setDestinationInExternalPublicDir(Environment.DIRECTORY_DOWNLOADS,safeName(uri.lastPathSegment?:"video.mp4"));(getSystemService(Context.DOWNLOAD_SERVICE) as DownloadManager).enqueue(req);status.text="已提交系统下载管理器。若失败，可能是 URL 过期、需要 Cookie 或服务器限制。"}catch(e:Exception){status.text="提交失败：${e.message}"}}
 private fun downloadHls(master:String){try{var listUrl=master;var text=fetchText(listUrl);if(text.contains("#EXT-X-STREAM-INF")){val lines=text.lines();val i=lines.indexOfFirst{it.trim().startsWith("#EXT-X-STREAM-INF")};val next=if(i>=0)lines.drop(i+1).firstOrNull{it.isNotBlank()&&!it.trim().startsWith("#")}else null;if(next!=null){listUrl=URL(URL(listUrl),next.trim()).toString();text=fetchText(listUrl)}}
  if(text.lines().any{it.trim().startsWith("#EXT-X-KEY")&&!it.contains("METHOD=NONE")}){update("该 HLS 清单包含加密标记，本工具不会尝试解密。");return}
  val segs=text.lines().map{it.trim()}.filter{it.isNotEmpty()&&!it.startsWith("#")}.map{URL(URL(listUrl),it).toString()};if(segs.isEmpty()){update("没有找到分片，可能是动态直播清单或不支持的格式。");return}
  val dir=getExternalFilesDir(Environment.DIRECTORY_DOWNLOADS)?:filesDir;val out=File(dir,"video_${System.currentTimeMillis()}.ts");FileOutputStream(out).use{o->segs.forEachIndexed{i,s->val c=URL(s).openConnection() as HttpURLConnection;c.connectTimeout=15000;c.readTimeout=30000;c.setRequestProperty("User-Agent","Mozilla/5.0");c.inputStream.use{it.copyTo(o)};c.disconnect();update("下载未加密分片 ${i+1}/${segs.size}")}};update("完成：${out.absolutePath}\n输出为 TS 文件，部分播放器可以播放。")
 }catch(e:Exception){update("HLS 下载失败：${e.message}。可能需要 Cookie、请求头或动态签名 URL。")}}
 private fun fetchText(raw:String):String{val c=URL(raw).openConnection() as HttpURLConnection;c.connectTimeout=15000;c.readTimeout=20000;c.setRequestProperty("User-Agent","Mozilla/5.0");return try{c.inputStream.bufferedReader(Charsets.UTF_8).use{it.readText()}}finally{c.disconnect()}}
 private fun safeName(s:String)=s.replace(Regex("""[\\/:*?"<>|]"""),"_").ifBlank{"video.mp4"}
 private fun update(s:String){runOnUiThread{status.text=s}}
}
